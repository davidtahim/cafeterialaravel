<?php

namespace Illuminate\Broadcasting;

use RuntimeException;

class BroadcastException extends RuntimeException
{
    //
}
